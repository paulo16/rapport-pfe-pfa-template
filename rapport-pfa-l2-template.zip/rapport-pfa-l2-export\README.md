# Template Rapport PFA L2 Dev

Ce dossier contient une structure propre et prête à l'emploi pour rédiger un rapport de PFA avec Overleaf/LaTeX.

## Arborescence

- `main.tex` : point d’entrée du rapport
- `preamble.tex` : packages et configuration globale
- `frontmatter/` : pages préliminaires (résumé, remerciements, etc.)
- `chapters/` : chapitres principaux
- `appendices/` : annexes
- `images/` : images organisées par chapitre
- `tables/` : tableaux longs séparés
- `bib/` : références bibliographiques BibTeX
- `glossary/` : glossaire et acronymes
- `output/` : PDF générés localement

## Utilisation rapide (Overleaf)

1. Créer un projet Overleaf vide
2. Importer tout le contenu de ce dossier
3. Ouvrir `main.tex`
4. Compiler

## Utilisation locale (optionnel)

Compiler avec :

```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

ou utiliser `latexmk` si installé.
